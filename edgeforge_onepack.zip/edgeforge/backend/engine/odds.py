import json
from typing import Tuple, Dict

def decimal_to_prob(d: float) -> float:
    return 1.0 / d if d else 0.0

def remove_vig_two_way(p_over_raw: float, p_under_raw: float) -> Tuple[float, float]:
    s = (p_over_raw or 0.0) + (p_under_raw or 0.0)
    if s <= 0:
        return 0.5, 0.5
    return (p_over_raw or 0.0) / s, (p_under_raw or 0.0) / s

def remove_vig_three_way(ph: float, pd: float, pa: float):
    s = (ph or 0.0) + (pd or 0.0) + (pa or 0.0)
    if s <= 0:
        return 1/3, 1/3, 1/3
    return (ph or 0.0) / s, (pd or 0.0) / s, (pa or 0.0) / s

def remove_vig_nway(prob_map: Dict[str, float]) -> Dict[str, float]:
    s = sum((v or 0.0) for v in prob_map.values())
    if s <= 0:
        n = max(1, len(prob_map))
        return {k: 1.0/n for k in prob_map}
    return {k: (v or 0.0) / s for k, v in prob_map.items()}

def ev_decimal(price_decimal: float, p_fair: float) -> float:
    return p_fair * (price_decimal - 1.0) - (1.0 - p_fair)

def compute_ev_row(row):
    side = str(row.get("side") or "").upper()
    price = float(row.get("price_bet365") or 0.0)
    market_class = str(row.get("market_class") or "").upper()

    if market_class == "OU" or side in ["OVER","UNDER"]:
        p_over_raw = float(row.get("baseline_over_prob", 0.0) or 0.0)
        p_under_raw = float(row.get("baseline_under_prob", 0.0) or 0.0)
        p_over, p_under = remove_vig_two_way(p_over_raw, p_under_raw)
        p_fair = p_over if side == "OVER" else p_under
        return ev_decimal(price, p_fair), p_fair

    if market_class == "YN" or side in ["YES", "NO"]:
        p_yes_raw = float(row.get("baseline_yes_prob", 0.0) or 0.0)
        p_no_raw  = float(row.get("baseline_no_prob", 1.0 - p_yes_raw) or (1.0 - p_yes_raw))
        p_yes, p_no = remove_vig_two_way(p_yes_raw, p_no_raw)
        p_fair = p_yes if side == "YES" else p_no
        return ev_decimal(price, p_fair), p_fair

    if market_class == "THREE_WAY" or side in ["HOME","DRAW","AWAY"]:
        ph = float(row.get("baseline_home_prob", 0.0) or 0.0)
        pd = float(row.get("baseline_draw_prob", 0.0) or 0.0)
        pa = float(row.get("baseline_away_prob", 0.0) or 0.0)
        ph, pd, pa = remove_vig_three_way(ph, pd, pa)
        mapping = {"HOME": ph, "DRAW": pd, "AWAY": pa}
        p_fair = mapping.get(side, 0.0)
        return ev_decimal(price, p_fair), p_fair

    if market_class == "N_WAY":
        probs = row.get("baseline_probs_json") or row.get("probs_json")
        if isinstance(probs, str):
            try:
                probs = json.loads(probs or "{}")
            except Exception:
                probs = {}
        probs = {str(k).upper(): float(v or 0.0) for k, v in (probs or {}).items()}
        probs = remove_vig_nway(probs)
        p_fair = probs.get(side, 0.0)
        return ev_decimal(price, p_fair), p_fair

    if market_class == "BAND":
        probs = row.get("band_probs_json")
        if isinstance(probs, str):
            try:
                probs = json.loads(probs or "{}")
            except Exception:
                probs = {}
        probs = {str(k): float(v or 0.0) for k, v in (probs or {}).items()}
        probs = remove_vig_nway(probs)
        p_fair = probs.get(row.get("side"), 0.0)
        return ev_decimal(price, p_fair), p_fair

    if market_class == "JOINT":
        p_joint = float(row.get("joint_prob", 0.0) or 0.0)
        return ev_decimal(price, p_joint), p_joint

    p_fair = float(row.get("model_prob", 0.0) or 0.0)
    return ev_decimal(price, p_fair), p_fair
