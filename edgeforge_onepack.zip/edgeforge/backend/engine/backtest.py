from pathlib import Path
import pandas as pd
import numpy as np
from .odds import compute_ev_row

_CACHE = {"edges": None, "summary": None}

def latest_results():
    return _CACHE if _CACHE.get("summary") else None

def _load_csvs(data_dir: Path) -> pd.DataFrame:
    files = sorted(Path(data_dir).glob("historical/*.csv"))
    if not files:
        return pd.DataFrame()
    dfs = [pd.read_csv(f) for f in files]
    df = pd.concat(dfs, ignore_index=True)
    if "event_datetime" in df.columns:
        df["event_datetime"] = pd.to_datetime(df["event_datetime"], errors="coerce")
    return df

def run_backtest(data_dir: Path, edge_threshold: float = 0.02, kelly_fraction: float = 0.5):
    df = _load_csvs(data_dir)
    if df.empty:
        _CACHE["edges"] = pd.DataFrame()
        _CACHE["summary"] = {"n_bets": 0, "roi": 0.0, "pnl": 0.0, "hit_rate": 0.0, "kelly_fraction": kelly_fraction, "by_sport": {}}
        return _CACHE["summary"]

    evs, pfs = [], []
    for _, r in df.iterrows():
        ev, p = compute_ev_row(r)
        evs.append(ev); pfs.append(p)
    df["p_fair"] = pfs
    df["edge"] = evs

    sel = df[df["edge"] >= edge_threshold].copy()
    if sel.empty:
        _CACHE["edges"] = df
        _CACHE["summary"] = {"n_bets": 0, "roi": 0.0, "pnl": 0.0, "hit_rate": 0.0, "kelly_fraction": kelly_fraction, "by_sport": {}}
        return _CACHE["summary"]

    d = sel["price_bet365"].astype(float)
    p = sel["p_fair"].astype(float)
    kelly_star = (p * d - 1.0) / (d - 1.0)
    kelly_star = kelly_star.clip(lower=0.0, upper=0.5)
    sel["stake"] = kelly_star * kelly_fraction

    won = sel["outcome"].astype(int)
    sel["pnl"] = np.where(won == 1, sel["stake"] * (d - 1.0), -sel["stake"])

    total_staked = sel["stake"].sum()
    total_pnl = sel["pnl"].sum()
    roi = (total_pnl / total_staked) if total_staked > 0 else 0.0
    hit_rate = won.mean()

    by_sport = (
        sel.groupby("sport")
        .agg(n_bets=("sport", "size"), pnl=("pnl", "sum"), staked=("stake", "sum"))
        .assign(roi=lambda x: x["pnl"] / x["staked"])
        .to_dict(orient="index")
    )

    _CACHE["edges"] = sel.sort_values("edge", ascending=False).reset_index(drop=True)
    _CACHE["summary"] = {
        "n_bets": int(sel.shape[0]),
        "roi": float(roi),
        "pnl": float(total_pnl),
        "hit_rate": float(hit_rate),
        "kelly_fraction": float(kelly_fraction),
        "by_sport": {k: {"n_bets": int(v["n_bets"]), "pnl": float(v["pnl"]), "staked": float(v["staked"]), "roi": float(v["roi"])} for k, v in by_sport.items()},
    }
    return _CACHE["summary"]
