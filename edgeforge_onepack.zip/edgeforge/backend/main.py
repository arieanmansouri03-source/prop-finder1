from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
from pathlib import Path
import pandas as pd
import json, os

from engine.backtest import run_backtest, latest_results

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data" / "historical"
CONFIG_FILE = BASE_DIR / "config.json"

app = FastAPI(title="EdgeForge API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class BacktestResponse(BaseModel):
    n_bets: int
    roi: float
    pnl: float
    hit_rate: float
    kelly_fraction: float
    by_sport: Dict[str, Dict[str, float]]

@app.post("/api/config")
async def save_config(config: str = Form(...)):
    # Spara API-nycklar/inställningar i config.json
    data = json.loads(config)
    CONFIG_FILE.write_text(json.dumps(data, indent=2))
    return {"ok": True}

@app.get("/api/config")
async def get_config():
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}

@app.post("/api/data/upload")
async def upload_csv(file: UploadFile = File(...)):
    # Tar emot en CSV med historik enligt vårt schema och sparar i data/historical/
    contents = await file.read()
    out = DATA_DIR / file.filename
    out.write_bytes(contents)
    # validera basic: kan läsas som CSV
    try:
        _ = pd.read_csv(out, nrows=5)
    except Exception as e:
        out.unlink(missing_ok=True)
        return {"ok": False, "error": str(e)}
    return {"ok": True, "filename": file.filename}

@app.post("/api/backtest/run", response_model=BacktestResponse)
async def api_backtest_run(edge_threshold: float = 0.02, kelly_fraction: float = 0.5):
    summary = run_backtest(BASE_DIR / "data", edge_threshold=edge_threshold, kelly_fraction=kelly_fraction)
    return BacktestResponse(**summary)

@app.get("/api/edges")
async def api_edges(min_edge: float = 0.02, sport: Optional[str] = None, limit: int = 500):
    res = latest_results()
    if not res or res.get("edges") is None:
        return []
    df = res["edges"].copy()
    if sport:
        df = df[df["sport"].str.upper() == sport.upper()]
    df = df[df["edge"] >= min_edge].sort_values("edge", ascending=False).head(limit)
    return df.to_dict(orient="records")

from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
FRONTEND_DIR = (BASE_DIR.parent / "frontend").resolve()
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR, html=False), name="static")

@app.get("/")
def serve_index():
    index_path = FRONTEND_DIR / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    return {"ok": True, "message": "EdgeForge API is running"}
