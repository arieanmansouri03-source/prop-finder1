import pandas as pd

def fetch_playerprops_example(api_key: str) -> pd.DataFrame:
    # TODO: implementera. Ska returnera DF enligt schema:
    # ['sport','league','event_id','event_datetime','market_type','market_class','player',
    #  'line','side','price_bet365', ... baseline_* ..., 'outcome'(om historik)]
    return pd.DataFrame([])
