# Lägg riktiga datakopplingar här (exchange, aggregatorer, dataleverantörer).
# Varje adapter bör exponera funktioner som returnerar pandas.DataFrame i samma schema som CSV:erna i /data/historical.
