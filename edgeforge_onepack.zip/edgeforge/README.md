# EdgeForge – Player Props +EV (bet365-fokus)

Detta är en färdig mall där du kan:
- Ladda upp **historisk CSV** för props/linjer (alla sporter, med fotboll som fokus).
- Spara **API-nycklar** för riktiga odds-feeds (valfritt).
- Köra **backtest** (vig-borttagning, EV, Kelly) och visa **edges** i UI.

## Snabbstart (lokalt)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```
Öppna sedan `frontend/index.html` i din webbläsare (pratar med `http://127.0.0.1:8000`).

## Ladda upp historik
Ladda upp valfritt antal CSV-filer via UI:t. De hamnar i `backend/data/historical/`. Backtest körs över **alla** dessa filer.

### Schema (kolumner)
Minsta uppsättning (beroende på marknadsklass):
- Gemensamt: `sport, league, event_id, event_datetime, market_type, market_class, player, line, side, price_bet365, outcome`
- OU: `baseline_over_prob, baseline_under_prob`
- YN: `baseline_yes_prob` (alt. även `baseline_no_prob`)
- THREE_WAY: `baseline_home_prob, baseline_draw_prob, baseline_away_prob`
- N_WAY: `baseline_probs_json` (dict outcome->prob)
- BAND: `band_probs_json` (dict band->prob) där `side` är bandnyckeln (t.ex. "20-29")
- JOINT: `joint_prob`

Rekommenderade fält: `team, opponent, period, alt_index, features_json`.

## Adapters (riktiga feeds)
Lägg egen kod i `backend/adapters/` (se `example.py`). Returnera en pandas-DataFrame i **samma schema som ovan** och spara den som CSV i `backend/data/historical/` för backtest.

## Viktigt
- Respektera dataleverantörers TOS (vi scrapar inte bet365).
- Spela ansvarsfullt.
