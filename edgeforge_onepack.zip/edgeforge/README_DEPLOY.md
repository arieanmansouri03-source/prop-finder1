# EdgeForge – One-Pack Deploy

## Kör lokalt med Docker (en rad)

```bash
docker compose up --build
# öppna http://localhost:8000  (frontend visas från samma server)
```

## Railway (superenkelt)
1) Skapa ett GitHub-repo och pusha hela mappen.
2) Gå till Railway → "New Project" → "Deploy from GitHub".
3) Välj ditt repo. Railway hittar `Dockerfile` automatiskt.
4) När deployment är klar får du en URL, t.ex. `https://edgeforge.up.railway.app` (API + frontend på samma url).

## Render (liknande)
1) Koppla ditt GitHub-repo i Render → "New Web Service".
2) Välj repo. Render känner av `Dockerfile`. Startkommandot är redan satt i `CMD` (uvicorn).
3) Klart – frontend och API på samma adress.

## Replit (om du vill slippa GitHub)
1) Skapa en ny Repl → välj "Import from GitHub" och klistra in URL till ditt repo.
2) Lägg till en "Deployment" (Always On). Replit bygger Dockerfile:en.
3) Öppna den publika URL:en.

Tips: Frontend serveras från FastAPI, så du behöver **inte** Netlify/Vercel separat.
